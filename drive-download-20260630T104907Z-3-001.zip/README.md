# Nxgo — Your Taiwan Buddy

A multi-page travel companion platform for exploring Taiwan, built as a university Database Management final project. Nxgo connects travelers with local buddies, eco-activities, and a community forum — all powered by the browser's `localStorage` as a client-side database.

## Features

- **User Authentication** — Register, login, and logout with session management. Profile and Dashboard pages are protected.
- **Data Management (CRUD)** — Create, read, update, and delete travel activities on the Destinations page. All changes persist in `localStorage`.
- **Search & Retrieval** — Keyword search with category and interest-tag filters. Graceful "no results" state.
- **Interactive Forum** — Post stories, ask questions, and reply with comments on the Profile page. Updates appear instantly.
- **Analytics Dashboard** — Admin dashboard with Chart.js visualizations: signups, posts over time, category/interest distribution, and most-viewed destinations. All numbers come from live `localStorage` data.

## Pages

| Page | File | Description |
|------|------|-------------|
| Home | `index.html` | Hero, discovery cards, destination grid, interest pills |
| Destinations | `destinations.html` | Activity cards, Taichung section, search + CRUD |
| Gallery | `gallery.html` | Photo collage and travel quote grid |
| Profile | `profile.html` | User profile, memories grid, forum feed (login required) |
| Dashboard | `dashboard.html` | Analytics charts (admin login required) |
| Login | `login.html` | Split-panel login form |
| Register | `register.html` | Split-panel registration form |

## Demo Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Traveler | `kim@nxgo.tw` | `password123` |
| Admin | `admin@nxgo.tw` | `admin123` |

## How to Run Locally

1. Clone or download this repository.
2. Open `index.html` in any modern browser (Chrome, Firefox, Safari, Edge).
3. No build step, no server, no npm install required.

> **Note:** On first load, `js/seed.js` automatically populates `localStorage` with demo users, destinations, forum posts, and activity log data.

To reset all data, open the browser console and run:
```js
localStorage.clear(); location.reload();
```

## How to Deploy on GitHub Pages

1. Push this project to a public GitHub repository.
2. Go to **Settings → Pages** in your repo.
3. Under **Source**, select the `main` branch and `/ (root)` folder.
4. Click **Save**. Your site will be live at `https://<username>.github.io/<repo-name>/`.

No configuration files needed — all files are static HTML, CSS, and JavaScript.

## File Structure

```
├── index.html              # Home page
├── destinations.html       # Destinations + Search + CRUD
├── gallery.html            # Photo gallery
├── profile.html            # User profile + forum
├── dashboard.html          # Admin analytics dashboard
├── login.html              # Login page
├── register.html           # Registration page
├── css/
│   └── style.css           # Global styles
├── js/
│   ├── seed.js             # Demo data seeder (runs once)
│   ├── data.js             # localStorage CRUD layer
│   ├── auth.js             # Authentication & sessions
│   ├── app.js              # Shared utilities (navbar, footer)
│   ├── destinations.js     # Search & CRUD logic
│   ├── profile.js          # Forum / stories logic
│   └── dashboard.js        # Chart.js analytics
└── README.md
```

## Data Model

Three main "tables" stored as JSON arrays in `localStorage`:

- **users** — `user_id`, `username`, `email`, `password`, `role`
- **posts** — `post_id`, `user_id`, `post_date`, `content`, `questions`, `comments[]`
- **travel_packages** — `prog_id`, `prog_name`, `events`, `date`, `status`, `category`, `location`, `image`, `interests[]`
- **activity_log** — page views, searches, and signups for analytics

## Tech Stack

- Plain HTML, CSS, vanilla JavaScript
- [Chart.js](https://www.chartjs.org/) (CDN) for dashboard charts
- [Google Fonts — Outfit](https://fonts.google.com/specimen/Outfit)
- [Unsplash](https://unsplash.com/) for Taiwan travel photography

## License

Built for educational purposes as part of a university Database Management course.
